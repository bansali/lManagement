 export class Books {
bookTitle: string;
author: string[];
description: string;
isbn: string;
totalBooks: number;
thumbnailImage: string;
remainingBooks:number;
categories:string[]
ratingsCount: number;
averageRating:number;
}
