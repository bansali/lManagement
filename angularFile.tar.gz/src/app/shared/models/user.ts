export class User {
    userName: String;
    email: String;
    password: String;
    role:String;
    userId:String
   
}
// address:[String];
// genres:[String];
// profilePic:String;
// libraryId:Number;